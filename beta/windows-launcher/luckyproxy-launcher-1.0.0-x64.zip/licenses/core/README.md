# Core dependency notices

- `Wintun-LICENSE.txt`: prebuilt binary license from
  https://www.wintun.net/builds/wintun-0.14.1.zip (`wintun/LICENSE.txt`).
- `lwip-COPYING.txt`: notice supplied with the Windows beta 1.0.0 x64 package.

Ship this directory as `licenses/core/` beside the launcher. CMake copies it
to the application output; the downloader copies it into each binary version
directory before loading. These are notices for the supplied Windows networking
dependencies, not a complete license bill of materials for the core's statically
linked third-party code. The core publisher remains responsible for that bundle
and any corresponding-source obligations before public redistribution.
